<footer>
    <h3 class="text-center">Siguenos en : </h3><br>
    <ul class="list-unstyled text-center">
        <a href="https://www.facebook.com/catzillastoremty/" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom" title="Facebook">
            <img src="assets/icons/social-facebook.png" alt="facebook-icon">
        </a>
    </ul>
    <br><br><br>
    <h5 class="text-center tittles-pages-logo"> CATZILLA STORE &copy; 2019</h5>
</footer>
